#!/system/bin/sh
# 记录模块 - service.sh：服务启动时留一条记录
MODDIR="${MODDIR:-.}"
OUTDIR="$MODDIR/records"
if ! mkdir -p "$OUTDIR" 2>/dev/null || ! ( : > "$OUTDIR/.probe" ) 2>/dev/null; then
  OUTDIR="/data/local/tmp/shizukux.recorder"
  mkdir -p "$OUTDIR" 2>/dev/null
fi
rm -f "$OUTDIR/.probe" 2>/dev/null
STAMP="$(date '+%Y-%m-%d %H:%M:%S')"
echo "service-start time=$STAMP module=$SHIZUKU_MODULE_ID mode=$SHIZUKU_MODULE_MODE" >> "$OUTDIR/service.log"
echo "service record appended: $OUTDIR/service.log"
