#!/system/bin/sh
# selftest edit
