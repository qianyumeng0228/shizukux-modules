#!/system/bin/sh
echo selftest
