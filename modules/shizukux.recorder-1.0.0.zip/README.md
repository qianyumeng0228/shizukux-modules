# 记录模块 (shizukux.recorder)

ShizukuX ADB 模块示例：把设备信息与运行状态记录到模块目录。

- `action.sh`：采集型号、品牌、Android 版本、SDK、ABI、构建号、uptime、内存、
  `/data` 空间与执行身份，写入 `records/record-<时间>.txt`，并保留一份 `records/latest.txt`。
- `service.sh`：在模块服务启动时向 `records/service.log` 追加一条记录。

查看记录：模块页 → 记录模块 → 动作（Action），输出即本次记录内容；
文件保存在 `/data/user/0/xyz.shizuku.extra.api/files/adb_modules/shizukux.recorder/records/`。

环境变量与 Shizuku.com 的 ADB 模块规范一致：`MODDIR`、`ASH_STANDALONE`、
`SHIZUKU_MODULE_ID`、`SHIZUKU_MODULE_MODE`、`SHIZUKU_MODULE_TRUSTED`、
`SHIZUKU_MODULE_BACKGROUND`。脚本通过 Shizuku 服务执行，不需要 Root。
