#!/system/bin/sh
# 记录模块 - service.sh：服务启动时留一条记录
MODDIR="${MODDIR:-.}"
OUTDIR="$MODDIR/records"
mkdir -p "$OUTDIR" 2>/dev/null
STAMP="$(date '+%Y-%m-%d %H:%M:%S')"
echo "service-start time=$STAMP module=$SHIZUKU_MODULE_ID mode=$SHIZUKU_MODULE_MODE" >> "$OUTDIR/service.log"
echo "service record appended: $OUTDIR/service.log"
