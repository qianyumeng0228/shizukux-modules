#!/system/bin/sh
# 记录模块 - 采集设备信息并写入模块目录
# 运行环境：Shizuku (ADB shell uid 2000 或 root)，工作目录已切到模块目录。
MODDIR="${MODDIR:-.}"
OUTDIR="$MODDIR/records"
mkdir -p "$OUTDIR" 2>/dev/null

STAMP="$(date '+%Y-%m-%d %H:%M:%S')"
FILE="$OUTDIR/record-$(date '+%Y%m%d-%H%M%S').txt"
LATEST="$OUTDIR/latest.txt"

{
  echo "time=$STAMP"
  echo "module=$SHIZUKU_MODULE_ID"
  echo "mode=$SHIZUKU_MODULE_MODE"
  echo "trusted=$SHIZUKU_MODULE_TRUSTED"
  echo "uid=$(id -u 2>/dev/null) user=$(id -un 2>/dev/null)"
  echo "model=$(getprop ro.product.model)"
  echo "brand=$(getprop ro.product.brand)"
  echo "device=$(getprop ro.product.device)"
  echo "android=$(getprop ro.build.version.release) sdk=$(getprop ro.build.version.sdk)"
  echo "abi=$(getprop ro.product.cpu.abi)"
  echo "build=$(getprop ro.build.display.id)"
  echo "uptime=$(uptime 2>/dev/null | tr -s ' ')"
  echo "mem=$(free -m 2>/dev/null | sed -n '2p' | tr -s ' ')"
  echo "storage=$(df -h /data 2>/dev/null | sed -n '2p' | tr -s ' ')"
} > "$FILE" 2>&1
cp "$FILE" "$LATEST" 2>/dev/null

cat "$FILE"
echo ""
echo "record saved: $FILE"
