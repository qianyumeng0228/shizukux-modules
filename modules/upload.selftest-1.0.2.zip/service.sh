#!/system/bin/sh
# selftest
