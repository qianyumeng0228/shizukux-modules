#!/system/bin/sh
echo demo
